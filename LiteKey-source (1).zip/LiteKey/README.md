# LiteKey
Tiny Android keyboard (IME). Dark by default, light switchable (key on the keyboard or in the app).
Pure Java, one custom View, no AppCompat/Gradle/XML layouts -> small APK and instant show-up.

Build on Ubuntu:  ./build.sh   -> LiteKey.apk
Or push to GitHub: Actions tab -> "Build APK" -> download artifact.

Install, open LiteKey, tap "1. Enable", then "2. Set as default".

Features: dark/light theme, 2 symbol pages (?123 -> =\<), English/French/Arabic layouts.
Enable languages in the app; swipe left/right or long-press the space bar to switch.
