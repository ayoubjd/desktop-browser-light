#!/usr/bin/env bash
# Builds lib/arm64-v8a and lib/armeabi-v7a liblitewhisper.so (whisper.cpp, CPU) with plain Ubuntu clang
# + the Android sysroot from an NDK archive hosted on GitHub (no dl.google.com needed).
# Usage: LITEKEY_DIR=/path/to/LiteKey ./build-native.sh
set -euo pipefail
SRC="${LITEKEY_DIR:?set LITEKEY_DIR to the LiteKey project folder}"
W=${WORK:-/tmp/litekey-native}; mkdir -p "$W"; cd "$W"
command -v clang++ >/dev/null || { apt-get update && apt-get install -y clang lld cmake make llvm; }
[ -d whisper.cpp ] || git clone --depth 1 https://github.com/ggml-org/whisper.cpp.git
if [ ! -d ndk/android-ndk-r29 ]; then   # only the target sysroot + runtime libs are used (host binaries are not)
  [ -f ndk.tar.xz ] || curl -L -o ndk.tar.xz https://github.com/lzhiyong/termux-ndk/releases/download/android-ndk/android-ndk-r29-aarch64.tar.xz
  mkdir -p ndk; tar -xf ndk.tar.xz -C ndk --wildcards '*sysroot*' '*/lib/clang/21/lib/linux/*' || true
fi
R=$W/ndk/android-ndk-r29/toolchains/llvm/prebuilt/linux-x86_64; CL=$R/lib/clang/21/lib/linux

build() {  # abi triple sysroot-dir clang-rt-name unwind-dir cpu-flags processor extra-cmake
  local ABI=$1 TRIPLE=$2 SD=$3 RT=$4 UD=$5 FLAGS=$6 PROC=$7 EXTRA=$8
  local S=$R/sysroot/usr/lib/$SD
  cat > tc-$ABI.cmake <<T
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR $PROC)
set(CMAKE_C_COMPILER clang)
set(CMAKE_CXX_COMPILER clang++)
set(CMAKE_C_COMPILER_TARGET ${TRIPLE}26)
set(CMAKE_CXX_COMPILER_TARGET ${TRIPLE}26)
set(CMAKE_SYSROOT $R/sysroot)
set(CMAKE_C_FLAGS_INIT "-fPIC -O3 $FLAGS")
set(CMAKE_CXX_FLAGS_INIT "-fPIC -O3 $FLAGS -nostdinc++ -isystem $R/sysroot/usr/include/c++/v1")
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
T
  cmake -S whisper.cpp -B wbuild-$ABI -DCMAKE_TOOLCHAIN_FILE=$W/tc-$ABI.cmake -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_SHARED_LIBS=OFF -DGGML_OPENMP=OFF -DGGML_NATIVE=OFF -DGGML_CCACHE=OFF \
    -DWHISPER_BUILD_EXAMPLES=OFF -DWHISPER_BUILD_TESTS=OFF -DWHISPER_BUILD_SERVER=OFF $EXTRA
  make -C wbuild-$ABI -j"$(nproc)" whisper
  clang++ --target=${TRIPLE}26 --sysroot=$R/sysroot -O2 -fPIC $FLAGS -nostdinc++ -isystem $R/sysroot/usr/include/c++/v1 \
    -I whisper.cpp/include -I whisper.cpp/ggml/include -fuse-ld=lld -shared -nostdlib -Wl,-z,max-page-size=16384 \
    "$SRC/jni/whisper_jni.cpp" -o liblitewhisper-$ABI.so $S/26/crtbegin_so.o \
    -Wl,--start-group wbuild-$ABI/src/libwhisper.a wbuild-$ABI/ggml/src/libggml.a wbuild-$ABI/ggml/src/libggml-cpu.a wbuild-$ABI/ggml/src/libggml-base.a -Wl,--end-group \
    $S/libc++_static.a $S/libc++abi.a $CL/$UD/libunwind.a $CL/libclang_rt.builtins-$RT-android.a \
    -L$S/26 -lc -lm -ldl -llog $S/26/crtend_so.o
  llvm-strip --strip-unneeded liblitewhisper-$ABI.so
  mkdir -p "$SRC/lib/$ABI"; cp liblitewhisper-$ABI.so "$SRC/lib/$ABI/liblitewhisper.so"
}

build arm64-v8a   aarch64-linux-android      aarch64-linux-android      aarch64 aarch64 ""                                  aarch64  "-DGGML_CPU_ARM_ARCH=armv8-a"
build armeabi-v7a armv7a-linux-androideabi   arm-linux-androideabi      arm     arm     "-mthumb -mfpu=neon-vfpv4 -mfloat-abi=softfp" armv7-a  "-DGGML_LLAMAFILE=OFF"
echo "Done: $SRC/lib/*/liblitewhisper.so"
