#!/usr/bin/env bash
# Manual toolchain build (no Gradle): aapt2 -> javac -> d8 -> zipalign -> apksigner
# Works on Ubuntu 22.04/24.04. Produces LiteKey.apk (min Android 8.0, targets 8.1 / API 27).
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_HOME:-$HOME/android-sdk}"
BT_VER="34.0.0"
PLATFORM="android-27"

# 1) Ubuntu packages
if ! command -v javac >/dev/null || ! command -v zip >/dev/null; then
  sudo apt-get update
  sudo apt-get install -y openjdk-17-jdk-headless zip unzip wget
fi

# 2) Android SDK pieces from Google (cmdline-tools -> build-tools + platform 27)
if [ ! -d "$SDK/build-tools/$BT_VER" ] || [ ! -f "$SDK/platforms/$PLATFORM/android.jar" ]; then
  if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
    mkdir -p "$SDK/cmdline-tools"
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O /tmp/clt.zip
    unzip -q -o /tmp/clt.zip -d "$SDK/cmdline-tools"
    rm -rf "$SDK/cmdline-tools/latest"
    mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
  fi
  yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" --licenses >/dev/null || true
  "$SDK/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$SDK" "build-tools;$BT_VER" "platforms;$PLATFORM"
fi

BT="$SDK/build-tools/$BT_VER"
JAR="$SDK/platforms/$PLATFORM/android.jar"
B=build
rm -rf "$B"; mkdir -p "$B/classes"

# 3) resources + manifest
"$BT/aapt2" compile --dir res -o "$B/res.zip"
"$BT/aapt2" link -o "$B/base.apk" -I "$JAR" --manifest AndroidManifest.xml \
  --min-sdk-version 26 --target-sdk-version 27 --version-code 1 --version-name 1.0 "$B/res.zip"

# 4) Java -> classes -> dex
javac -encoding UTF-8 -Xlint:-options --release 8 -classpath "$JAR" -d "$B/classes" $(find src -name '*.java')
"$BT/d8" --release --min-api 26 --lib "$JAR" --output "$B" $(find "$B/classes" -name '*.class')
(cd "$B" && zip -q -j base.apk classes.dex)
[ -d lib ] && zip -qr "$B/base.apk" lib   # prebuilt whisper.cpp (see build-native.sh)

# 5) align + sign
[ -f debug.keystore ] || keytool -genkeypair -keystore debug.keystore -storepass android -keypass android \
  -alias key -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=LiteKey"
"$BT/zipalign" -f -p 4 "$B/base.apk" "$B/aligned.apk"
"$BT/apksigner" sign --ks debug.keystore --ks-pass pass:android --key-pass pass:android \
  --out LiteKey.apk "$B/aligned.apk"
"$BT/apksigner" verify LiteKey.apk
echo "Done: $(pwd)/LiteKey.apk ($(du -h LiteKey.apk | cut -f1))"
