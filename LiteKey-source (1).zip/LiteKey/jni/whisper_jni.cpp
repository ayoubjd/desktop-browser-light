// Thin JNI bridge to whisper.cpp (CPU only). Returns UTF-8 bytes so Java decodes safely.
#include <jni.h>
#include <string>
#include <atomic>
#include <chrono>
#include <algorithm>
#include <cmath>
#include "whisper.h"

static std::atomic<bool> g_cancel(false);
static std::atomic<long long> g_deadline_ms(0);

static long long now_ms() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

// Called by ggml between graph operations: true = stop now (user cancel or timeout).
static bool abort_cb(void*) {
    return g_cancel.load() || now_ms() > g_deadline_ms.load();
}

extern "C" {

JNIEXPORT jlong JNICALL Java_com_lite_keyboard_Whisper_nativeInit(JNIEnv* env, jclass, jstring path) {
    const char* p = env->GetStringUTFChars(path, nullptr);
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    cp.flash_attn = false;   // CPU flash-attention is very slow on 32-bit/old ARM; classic path is faster
    whisper_context* ctx = whisper_init_from_file_with_params(p, cp);
    env->ReleaseStringUTFChars(path, p);
    return (jlong)(intptr_t)ctx;
}

JNIEXPORT void JNICALL Java_com_lite_keyboard_Whisper_nativeCancel(JNIEnv*, jclass) {
    g_cancel = true;
}

JNIEXPORT jbyteArray JNICALL Java_com_lite_keyboard_Whisper_nativeTranscribe(
        JNIEnv* env, jclass, jlong h, jfloatArray pcm, jint n, jstring lang, jint threads, jint timeoutSec) {
    whisper_context* ctx = (whisper_context*)(intptr_t)h;
    if (!ctx) return nullptr;
    const char* l = env->GetStringUTFChars(lang, nullptr);
    std::string language(l);
    env->ReleaseStringUTFChars(lang, l);

    jfloat* data = env->GetFloatArrayElements(pcm, nullptr);
    whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.print_progress = false; wp.print_realtime = false;
    wp.print_timestamps = false; wp.print_special = false;
    wp.translate = false;
    wp.no_context = true;
    wp.suppress_blank = true;
    wp.no_timestamps = true;       // faster decoding, we only need the text
    wp.single_segment = true;      // a dictation clip is always < 30 s
    wp.temperature_inc = 0.0f;     // NO fallback re-decodes (they multiplied the time by up to 6x)
    wp.greedy.best_of = 1;
    wp.n_threads = threads;
    wp.language = language.c_str();      // "ar" forces Arabic script; "auto" = detect

    // The encoder normally processes a full 30 s window (1500 frames, 50 per second).
    // Short clips only need a fraction of it: this is the biggest speed-up on slow phones.
    double secs = n / 16000.0;
    int ac = (int)std::ceil(secs * 50.0 * 1.25) + 64;
    ac = ((ac + 31) / 32) * 32;
    wp.audio_ctx = std::max(384, std::min(1500, ac));

    g_cancel = false;
    g_deadline_ms = now_ms() + (long long)timeoutSec * 1000LL;
    wp.abort_callback = abort_cb;
    wp.abort_callback_user_data = nullptr;

    int rc = whisper_full(ctx, wp, data, n);
    env->ReleaseFloatArrayElements(pcm, data, JNI_ABORT);
    if (rc != 0 || g_cancel.load() || now_ms() > g_deadline_ms.load()) return nullptr;

    std::string out;
    int segs = whisper_full_n_segments(ctx);
    for (int i = 0; i < segs; i++) out += whisper_full_get_segment_text(ctx, i);
    jbyteArray arr = env->NewByteArray((jsize)out.size());
    env->SetByteArrayRegion(arr, 0, (jsize)out.size(), (const jbyte*)out.data());
    return arr;
}

JNIEXPORT void JNICALL Java_com_lite_keyboard_Whisper_nativeFree(JNIEnv*, jclass, jlong h) {
    if (h) whisper_free((whisper_context*)(intptr_t)h);
}

}
