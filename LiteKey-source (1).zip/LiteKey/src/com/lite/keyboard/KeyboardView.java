package com.lite.keyboard;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

/** Single custom View, no XML inflation, no allocations while drawing. */
public class KeyboardView extends View {

    static final int T_CHAR = 0, T_SHIFT = 1, T_DEL = 2, T_SYM = 3, T_ABC = 4,
            T_SPACE = 5, T_ENTER = 6, T_THEME = 7, T_SPACER = 8, T_MORE = 9, T_MIC = 10;

    static final class Key {
        int type; String label; String upper; float w;
        float l, t, r, b; boolean pressed; boolean special;
    }

    // token format: code|weight   (code = single char or SHIFT DEL SYM ABC SPACE ENTER THEME MORE _ ; "__" = underscore char)
    static final String[] L_CODE = {"en", "fr", "ar"};
    static final String[] L_NAME = {"English", "Fran\u00e7ais", "\u0627\u0644\u0639\u0631\u0628\u064a\u0629"};
    static final String[] L_ABC = {"ABC", "ABC", "\u0623\u0628"};

    private static final String[][] EN = {
        {"q","w","e","r","t","y","u","i","o","p"},
        {"_|0.5","a","s","d","f","g","h","j","k","l","_|0.5"},
        {"SHIFT|1.5","z","x","c","v","b","n","m","DEL|1.5"},
        {"THEME|1.2","SYM|1.2","MIC|1.2",",","SPACE|3.4",".","ENTER|1.5"}
    };
    private static final String[][] FR = {
        {"\u00e9","\u00e8","\u00ea","\u00e0","\u00e2","\u00e7","\u00f9","\u00fb","\u00f4","\u00ee"},
        {"a","z","e","r","t","y","u","i","o","p"},
        {"q","s","d","f","g","h","j","k","l","m"},
        {"SHIFT|1.5","w","x","c","v","b","n","'","DEL|1.5"},
        {"THEME|1.2","SYM|1.2","MIC|1.2",",","SPACE|3.4",".","ENTER|1.5"}
    };
    private static final String[][] AR = {
        {"\u0636","\u0635","\u062b","\u0642","\u0641","\u063a","\u0639","\u0647","\u062e","\u062d","\u062c"},
        {"\u0634","\u0633","\u064a","\u0628","\u0644","\u0627","\u062a","\u0646","\u0645","\u0643","\u0637"},
        {"\u0626","\u0621","\u0624","\u0631","\u0649","\u0629","\u0648","\u0632","\u0638","\u062f","\u0630","DEL|1.5"},
        {"THEME|1.2","SYM|1.2","MIC|1.2","\u060c","SPACE|3.4",".","ENTER|1.5"}
    };
    private static final String[][][] L_ROWS = {EN, FR, AR};

    // Symbols page 1: digits + everyday signs
    private static final String[][] SYMBOLS = {
        {"1","2","3","4","5","6","7","8","9","0"},
        {"@","#","$","%","&","-","+","(",")","/"},
        {"MORE|1.5","*","\"","'",":",";","!","?","DEL|1.5"},
        {"THEME|1.3","ABC|1.3",",","SPACE|4",".","ENTER|1.6"}
    };
    // Symbols page 2: most used extra signs
    private static final String[][] SYMBOLS2 = {
        {"~","`","|","\u2022","\u00f7","\u00d7","\u00a9","\u00ae","\u061f","\u060c"},
        {"\u20ac","\u00a3","\u00a5","\u00a2","^","\u00b0","=","{","}","\\"},
        {"MORE|1.5","[","]","<",">","\u00ab","\u00bb","__","DEL|1.5"},
        {"THEME|1.3","ABC|1.3",",","SPACE|4",".","ENTER|1.6"}
    };

    private final LiteKeyboardService service;
    private final SharedPreferences prefs;
    private final Handler handler = new Handler();
    private final Key[][][] langKeys = new Key[3][][];
    private final Key[][] symKeys, sym2Keys;
    private final Key[] down = new Key[16];

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();

    private boolean symbols = false, dark = true, autoCap = false;
    private int voiceSecs = 0;
    private int voiceState = 0;         // VoiceInput.IDLE / LISTENING / PROCESSING
    private int symPage = 0;             // 0 = digits/signs, 1 = more signs
    private int lang = 0, nEnabled = 1;  // index into L_CODE, count of enabled languages
    private final int[] order = new int[3];
    private Key[][] laidFor; private int laidW, laidH;
    private int spaceId = -1; private float spaceX; private boolean spaceDone;
    private int shift = 0;               // 0 off, 1 once, 2 lock
    private long lastShiftTap = 0;
    private String enterLabel = "Enter";
    private int cBg, cKey, cSpecial, cPressed, cText, cAccent;
    private float dp, sp, gap, radius, textY, specialY;

    public KeyboardView(LiteKeyboardService s) {
        super(s);
        service = s;
        prefs = s.getSharedPreferences("kb", Context.MODE_PRIVATE);
        DisplayMetrics dm = s.getResources().getDisplayMetrics();
        dp = dm.density; sp = dm.scaledDensity;
        gap = 5 * dp; radius = 6 * dp;
        for (int i = 0; i < 3; i++) langKeys[i] = parse(L_ROWS[i]);
        symKeys = parse(SYMBOLS);
        sym2Keys = parse(SYMBOLS2);
        loadLangs();
        p.setTextAlign(Paint.Align.CENTER);
        applyTheme();
        setHapticFeedbackEnabled(true);
    }

    private static Key[][] parse(String[][] src) {
        Key[][] out = new Key[src.length][];
        for (int i = 0; i < src.length; i++) {
            out[i] = new Key[src[i].length];
            for (int j = 0; j < src[i].length; j++) {
                String tok = src[i][j];
                String[] part = tok.equals("|") ? new String[]{"|"} : tok.split("\\|");
                Key k = new Key();
                String c = part[0];
                if (c.equals("__")) c = "_x";   // literal underscore marker
                k.w = part.length > 1 ? Float.parseFloat(part[1]) : 1f;
                if (c.equals("_")) k.type = T_SPACER;
                else if (c.equals("SHIFT")) { k.type = T_SHIFT; k.special = true; }
                else if (c.equals("DEL")) { k.type = T_DEL; k.special = true; }
                else if (c.equals("SYM")) { k.type = T_SYM; k.special = true; }
                else if (c.equals("ABC")) { k.type = T_ABC; k.special = true; }
                else if (c.equals("THEME")) { k.type = T_THEME; k.special = true; }
                else if (c.equals("MORE")) { k.type = T_MORE; k.special = true; }
                else if (c.equals("MIC")) { k.type = T_MIC; k.special = true; }
                else if (c.equals("SPACE")) { k.type = T_SPACE; }
                else if (c.equals("ENTER")) { k.type = T_ENTER; k.special = true; }
                else {
                    if (c.equals("_x")) c = "_";
                    k.type = T_CHAR; k.label = c; k.upper = c.toUpperCase();
                }
                out[i][j] = k;
            }
        }
        return out;
    }

    private Key[][] cur() {
        return symbols ? (symPage == 0 ? symKeys : sym2Keys) : langKeys[lang];
    }

    private void loadLangs() {
        String s = prefs.getString("langs", "en");
        nEnabled = 0;
        for (int i = 0; i < 3; i++) if (s.contains(L_CODE[i])) order[nEnabled++] = i;
        if (nEnabled == 0) { order[0] = 0; nEnabled = 1; }
        String c = prefs.getString("lang", "en");
        lang = order[0];
        for (int i = 0; i < nEnabled; i++) if (L_CODE[order[i]].equals(c)) lang = order[i];
    }

    private void switchLang(int dir) {
        if (nEnabled < 2) return;
        int pos = 0;
        for (int i = 0; i < nEnabled; i++) if (order[i] == lang) pos = i;
        lang = order[(pos + dir + nEnabled) % nEnabled];
        prefs.edit().putString("lang", L_CODE[lang]).apply();
        symbols = false; shift = 0;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        requestLayout();
        invalidate();
    }

    private void ensureLayout() {
        Key[][] k = cur();
        int w = getWidth(), h = getHeight();
        if (k != laidFor || w != laidW || h != laidH) {
            layoutKeys(k, w, h);
            laidFor = k; laidW = w; laidH = h;
        }
    }

    private void applyTheme() {
        dark = prefs.getBoolean("dark", true);      // dark by default
        if (dark) {
            cBg = 0xFF0E1014; cKey = 0xFF262A33; cSpecial = 0xFF1A1D24;
            cPressed = 0xFF3A4150; cText = 0xFFECEEF2;
        } else {
            cBg = 0xFFDCE0E8; cKey = 0xFFFFFFFF; cSpecial = 0xFFC3C9D4;
            cPressed = 0xFFAEB6C6; cText = 0xFF14171C;
        }
        cAccent = 0xFF3D7BFF;
    }

    /** Called each time the keyboard appears in a text field. */
    void reset(EditorInfo info) {
        applyTheme();
        loadLangs();
        symPage = 0;
        requestLayout();
        int cls = info.inputType & EditorInfo.TYPE_MASK_CLASS;
        symbols = (cls == EditorInfo.TYPE_CLASS_NUMBER || cls == EditorInfo.TYPE_CLASS_PHONE);
        autoCap = (info.inputType & EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0
                || (info.inputType & EditorInfo.TYPE_TEXT_FLAG_CAP_WORDS) != 0;
        shift = 0;
        if (info.inputType != 0) {
            InputConnection ic = service.getCurrentInputConnection();
            if (ic != null && ic.getCursorCapsMode(info.inputType) != 0) shift = 1;
        }
        int action = info.imeOptions & EditorInfo.IME_MASK_ACTION;
        if ((info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) enterLabel = "Enter";
        else switch (action) {
            case EditorInfo.IME_ACTION_GO: enterLabel = "Go"; break;
            case EditorInfo.IME_ACTION_SEARCH: enterLabel = "Search"; break;
            case EditorInfo.IME_ACTION_SEND: enterLabel = "Send"; break;
            case EditorInfo.IME_ACTION_NEXT: enterLabel = "Next"; break;
            case EditorInfo.IME_ACTION_DONE: enterLabel = "Done"; break;
            default: enterLabel = "Enter";
        }
        invalidate();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        boolean land = dm.widthPixels > dm.heightPixels;
        int rowH = (int) ((land ? 40 : 52) * dp);
        setMeasuredDimension(w, rowH * L_ROWS[lang].length + (int) (6 * dp));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        laidFor = null;
        p.setTextSize(22 * sp);
        Paint.FontMetrics fm = p.getFontMetrics();
        textY = -(fm.ascent + fm.descent) / 2f;
        p.setTextSize(14 * sp);
        fm = p.getFontMetrics();
        specialY = -(fm.ascent + fm.descent) / 2f;
    }

    private void layoutKeys(Key[][] rows, int w, int h) {
        float rowH = h / (float) rows.length;
        for (int i = 0; i < rows.length; i++) {
            float total = 0;
            for (Key k : rows[i]) total += k.w;
            float x = 0, unit = w / total;
            for (Key k : rows[i]) {
                k.l = x; k.r = x + k.w * unit;
                k.t = i * rowH; k.b = (i + 1) * rowH;
                x = k.r;
            }
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(cBg);
        ensureLayout();
        Key[][] rows = cur();
        float g = gap / 2f;
        for (Key[] row : rows) {
            for (Key k : row) {
                if (k.type == T_SPACER) continue;
                int col = k.pressed ? cPressed
                        : (k.type == T_ENTER ? cAccent
                        : (k.type == T_MIC && voiceState == 1 ? 0xFFE53935
                        : (k.special ? cSpecial : cKey)));
                p.setStyle(Paint.Style.FILL);
                p.setColor(col);
                rect.set(k.l + g, k.t + g, k.r - g, k.b - g);
                c.drawRoundRect(rect, radius, radius, p);

                float cx = (k.l + k.r) / 2f, cy = (k.t + k.b) / 2f;
                p.setColor(k.type == T_ENTER ? 0xFFFFFFFF : cText);
                switch (k.type) {
                    case T_CHAR:
                        p.setTextSize(22 * sp);
                        c.drawText(shift != 0 && !symbols ? k.upper : k.label, cx, cy + textY, p);
                        break;
                    case T_SYM: p.setTextSize(14 * sp); c.drawText("?123", cx, cy + specialY, p); break;
                    case T_ABC: p.setTextSize(14 * sp); c.drawText(L_ABC[lang], cx, cy + specialY, p); break;
                    case T_MIC:
                        if (voiceState == 2) { p.setTextSize(15 * sp); c.drawText(voiceSecs + "s", cx, cy + specialY, p); }
                        else drawMic(c, cx, cy);
                        break;
                    case T_MORE: p.setTextSize(14 * sp); c.drawText(symPage == 0 ? "=\\<" : "?123", cx, cy + specialY, p); break;
                    case T_SPACE:
                        if (nEnabled > 1) {
                            p.setTextSize(12 * sp);
                            p.setColor((cText & 0x00FFFFFF) | 0x99000000);
                            c.drawText(L_NAME[lang], cx, cy + specialY, p);
                        }
                        break;
                    case T_THEME: p.setTextSize(13 * sp); c.drawText(dark ? "Light" : "Dark", cx, cy + specialY, p); break;
                    case T_ENTER: p.setTextSize(14 * sp); c.drawText(enterLabel, cx, cy + specialY, p); break;
                    case T_SHIFT: drawShift(c, cx, cy); break;
                    case T_DEL: drawDel(c, cx, cy); break;
                    default: break;
                }
            }
        }
    }

    private void drawShift(Canvas c, float cx, float cy) {
        float s = 9 * dp;
        path.reset();
        path.moveTo(cx, cy - s);
        path.lineTo(cx - s, cy);
        path.lineTo(cx - s / 2, cy);
        path.lineTo(cx - s / 2, cy + s * 0.8f);
        path.lineTo(cx + s / 2, cy + s * 0.8f);
        path.lineTo(cx + s / 2, cy);
        path.lineTo(cx + s, cy);
        path.close();
        p.setStyle(shift != 0 ? Paint.Style.FILL : Paint.Style.STROKE);
        p.setStrokeWidth(2 * dp);
        c.drawPath(path, p);
        if (shift == 2) {
            p.setStyle(Paint.Style.FILL);
            c.drawRect(cx - s / 2, cy + s, cx + s / 2, cy + s + 2 * dp, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawMic(Canvas c, float cx, float cy) {
        float s = 9 * dp;
        if (voiceState == 1) p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.FILL);
        rect.set(cx - s * 0.4f, cy - s, cx + s * 0.4f, cy + s * 0.2f);
        c.drawRoundRect(rect, s * 0.4f, s * 0.4f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f * dp);
        rect.set(cx - s * 0.75f, cy - s * 0.55f, cx + s * 0.75f, cy + s * 0.55f);
        c.drawArc(rect, 0, 180, false, p);
        c.drawLine(cx, cy + s * 0.55f, cx, cy + s, p);
        c.drawLine(cx - s * 0.4f, cy + s, cx + s * 0.4f, cy + s, p);
        p.setStyle(Paint.Style.FILL);
    }

    void setVoiceSeconds(int s) { voiceSecs = s; invalidate(); }

    void setVoiceState(int st) {
        voiceState = st;
        if (st != 2) voiceSecs = 0;
        invalidate();
    }

    private void drawDel(Canvas c, float cx, float cy) {
        float s = 9 * dp;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * dp);
        c.drawLine(cx + s, cy, cx - s, cy, p);
        c.drawLine(cx - s, cy, cx - s / 2, cy - s / 2, p);
        c.drawLine(cx - s, cy, cx - s / 2, cy + s / 2, p);
        p.setStyle(Paint.Style.FILL);
    }

    // ---------------------------------------------------------------- touch

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                press(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                release(e.getPointerId(e.getActionIndex()));
                break;
            case MotionEvent.ACTION_MOVE:
                if (spaceId >= 0 && nEnabled > 1) {
                    int idx = e.findPointerIndex(spaceId);
                    if (idx >= 0) {
                        float x = e.getX(idx);
                        if (Math.abs(x - spaceX) > 36 * dp) {
                            handler.removeCallbacks(spaceLong);
                            spaceDone = true;
                            switchLang(x > spaceX ? 1 : -1);
                            spaceX = x;
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_CANCEL:
                spaceDone = true;
                for (int i = 0; i < down.length; i++) release(i);
                break;
            default: break;
        }
        return true;
    }

    private Key hit(float x, float y) {
        ensureLayout();
        Key[][] rows = cur();
        for (Key[] row : rows)
            for (Key k : row)
                if (k.type != T_SPACER && x >= k.l && x < k.r && y >= k.t && y < k.b) return k;
        return null;
    }

    private void press(int id, float x, float y) {
        if (id >= down.length) return;
        Key k = hit(x, y);
        if (k == null) return;
        if (spaceId >= 0 && !spaceDone) flushSpace();   // keep typing order when keys overlap
        k.pressed = true;
        down[id] = k;
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (k.type == T_SPACE) {
            spaceId = id; spaceX = x; spaceDone = false;
            handler.removeCallbacks(spaceLong);
            if (nEnabled > 1) handler.postDelayed(spaceLong, 450);
        } else onKey(k);
        invalidate();
    }

    private void release(int id) {
        if (id >= down.length || down[id] == null) return;
        if (down[id].type == T_DEL) handler.removeCallbacks(repeatDel);
        if (down[id].type == T_SPACE && id == spaceId) {
            handler.removeCallbacks(spaceLong);
            if (!spaceDone) commitSpace();
            spaceId = -1; spaceDone = false;
        }
        down[id].pressed = false;
        down[id] = null;
        invalidate();
    }

    private final Runnable spaceLong = new Runnable() {
        @Override public void run() {
            if (spaceId >= 0 && !spaceDone) { spaceDone = true; switchLang(1); }
        }
    };

    private void flushSpace() {
        spaceDone = true;
        handler.removeCallbacks(spaceLong);
        commitSpace();
    }

    private void commitSpace() {
        InputConnection ic = service.getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(" ", 1);
        if (autoCap && shift == 0) {
            CharSequence b = ic.getTextBeforeCursor(2, 0);
            if (b != null && b.length() == 2 && b.charAt(1) == ' '
                    && ".!?".indexOf(b.charAt(0)) >= 0) shift = 1;
        }
        invalidate();
    }

    private final Runnable repeatDel = new Runnable() {
        @Override public void run() {
            service.sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            handler.postDelayed(this, 45);
        }
    };

    // ------------------------------------------------------------ key logic

    private void onKey(Key k) {
        InputConnection ic = service.getCurrentInputConnection();
        switch (k.type) {
            case T_CHAR:
                if (ic == null) return;
                ic.commitText(shift != 0 && !symbols ? k.upper : k.label, 1);
                if (shift == 1) shift = 0;
                break;
            case T_DEL:
                service.sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                handler.postDelayed(repeatDel, 400);
                break;
            case T_SHIFT: {
                long now = System.currentTimeMillis();
                if (shift == 0) shift = 1;
                else if (shift == 1 && now - lastShiftTap < 350) shift = 2;
                else shift = 0;
                lastShiftTap = now;
                break;
            }
            case T_SYM: symbols = true; symPage = 0; break;
            case T_ABC: symbols = false; break;
            case T_MORE: symPage = 1 - symPage; break;
            case T_MIC: service.toggleVoice(L_CODE[lang]); break;
            case T_THEME:
                prefs.edit().putBoolean("dark", !dark).apply();
                applyTheme();
                break;
            case T_ENTER: {
                EditorInfo ei = service.getCurrentInputEditorInfo();
                int action = ei == null ? 0 : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
                boolean noAction = ei == null
                        || (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                        || action == EditorInfo.IME_ACTION_NONE
                        || action == EditorInfo.IME_ACTION_UNSPECIFIED;
                if (noAction) service.sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
                else if (ic != null) ic.performEditorAction(action);
                break;
            }
            default: break;
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacks(repeatDel);
        handler.removeCallbacks(spaceLong);
        super.onDetachedFromWindow();
    }
}
