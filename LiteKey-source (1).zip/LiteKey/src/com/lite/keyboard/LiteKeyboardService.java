package com.lite.keyboard;

import android.content.Context;
import android.content.Intent;
import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Toast;

public class LiteKeyboardService extends InputMethodService {
    private KeyboardView view;
    private VoiceInput voice;

    @Override
    public View onCreateInputView() {
        view = new KeyboardView(this);
        return view;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (view != null) view.reset(info);
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        if (voice != null && voice.state() == VoiceInput.LISTENING) voice.cancel();
    }

    @Override
    public void onDestroy() {
        if (voice != null) voice.destroy();
        super.onDestroy();
    }

    // Never go fullscreen in landscape: lighter and faster.
    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    /** Mic key: tap to start dictation, tap again to stop early (it also stops by itself on silence). */
    void toggleVoice(String keyboardLang) {
        if (voice == null) voice = new VoiceInput(this, new VoiceInput.Listener() {
            @Override public void onState(int s) { if (view != null) view.setVoiceState(s); }
            @Override public void onTick(int sec) { if (view != null) view.setVoiceSeconds(sec); }
            @Override public void onText(String t) {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.commitText(t + " ", 1);
            }
            @Override public void onMessage(String m) {
                Toast.makeText(LiteKeyboardService.this, m, Toast.LENGTH_SHORT).show();
            }
        });
        int st = voice.state();
        if (st == VoiceInput.LISTENING || st == VoiceInput.PROCESSING) { voice.stop(); return; }   // 2nd tap: stop / cancel
        android.content.SharedPreferences sp = getSharedPreferences("kb", Context.MODE_PRIVATE);
        boolean cloud = "cloud".equals(sp.getString("engine", "cloud"));
        boolean ready;
        if (cloud) {
            ready = VoiceInput.hasMic(this) && Secrets.groqKey(this).length() > 0;
        } else {
            if (!Whisper.AVAILABLE) {
                Toast.makeText(this, "Offline voice is not supported on this phone (needs an ARM CPU)", Toast.LENGTH_LONG).show();
                return;
            }
            ready = VoiceInput.hasMic(this) && VoiceInput.hasModel(this);
        }
        if (!ready) {
            Toast.makeText(this, "Voice setup needed: open LiteKey", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, SettingsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return;
        }
        String pref = getSharedPreferences("kb", Context.MODE_PRIVATE).getString("dictlang", "follow");
        String lang = pref.equals("follow") ? keyboardLang : pref;   // "ar" forces Arabic script, "auto" detects
        voice.start(lang);
    }
}
