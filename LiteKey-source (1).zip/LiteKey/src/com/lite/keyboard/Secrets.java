package com.lite.keyboard;

import android.content.Context;

/** Personal-use build: the Groq key is built in. A key typed in Settings overrides it. */
final class Secrets {
    static final String GROQ_KEY = "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";

    static String groqKey(Context c) {
        String k = c.getSharedPreferences("kb", Context.MODE_PRIVATE).getString("groqkey", "").trim();
        return k.length() > 0 ? k : GROQ_KEY;
    }

    static boolean customKey(Context c) {
        return c.getSharedPreferences("kb", Context.MODE_PRIVATE).getString("groqkey", "").trim().length() > 0;
    }

    private Secrets() { }
}
