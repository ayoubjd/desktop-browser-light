package com.lite.keyboard;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** LiteKey settings: tabs (Setup / Voice / Languages / Look), dark + light theme shared with the keyboard. */
public class SettingsActivity extends Activity {
    private static final int REQ_MIC = 1, REQ_MODEL = 2;
    private static final String HF = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/";
    private static final String[] TAB_NAMES = {"Setup", "Voice", "Languages", "Look"};

    private SharedPreferences prefs;
    private InputMethodManager imm;
    private volatile boolean busy;

    private boolean dark;
    private int cBg, cCard, cText, cSub, cLine, cField;
    private static final int ACCENT = 0xFF3D7BFF;

    private TextView setupStatus, voiceStatus;
    private LinearLayout content;
    private ScrollView scroll;
    private final LinearLayout[] pages = new LinearLayout[4];
    private final TextView[] tabs = new TextView[4];
    private int curTab;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    // ------------------------------------------------------------------ UI helpers

    private GradientDrawable round(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private void ripple(View v, GradientDrawable bg) {
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null));
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout card(LinearLayout page, String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(round(cCard, 16, cLine));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        page.addView(c, lp);
        if (title != null) {
            TextView t = text(title, 16, cText, true);
            t.setPadding(0, 0, 0, dp(8));
            c.addView(t);
        }
        return c;
    }

    private TextView body(LinearLayout c, String s) {
        TextView t = text(s, 13, cSub, false);
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, dp(4), 0, dp(4));
        c.addView(t);
        return t;
    }

    private TextView button(LinearLayout c, String label, boolean primary, View.OnClickListener l) {
        TextView b = text(label, 15, primary ? 0xFFFFFFFF : cText, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), dp(13), dp(14), dp(13));
        ripple(b, primary ? round(ACCENT, 12, 0) : round(cField, 12, cLine));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        c.addView(b, lp);
        return b;
    }

    private ColorStateList tint() {
        return new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{ACCENT, cSub});
    }

    private RadioButton radio(RadioGroup g, String label, int id) {
        RadioButton r = new RadioButton(this);
        r.setText(label);
        r.setId(id);
        r.setTextSize(14);
        r.setTextColor(cText);
        r.setButtonTintList(tint());
        r.setPadding(dp(6), dp(8), 0, dp(8));
        g.addView(r);
        return r;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(cSub);
        e.setTextColor(cText);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackground(round(cField, 12, cLine));
        return e;
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("kb", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", true);
        setTheme(dark ? android.R.style.Theme_DeviceDefault_NoActionBar
                      : android.R.style.Theme_DeviceDefault_Light_NoActionBar);
        super.onCreate(b);
        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        if (dark) { cBg = 0xFF0E1014; cCard = 0xFF181B21; cText = 0xFFECEEF2; cSub = 0xFF9AA2B1; cLine = 0xFF2A2F39; cField = 0xFF0E1014; }
        else      { cBg = 0xFFF2F4F8; cCard = 0xFFFFFFFF; cText = 0xFF14171C; cSub = 0xFF5D6675; cLine = 0xFFD9DEE7; cField = 0xFFF2F4F8; }
        getWindow().setStatusBarColor(cBg);
        getWindow().setNavigationBarColor(cBg);
        if (!dark) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cBg);

        // header
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(dp(20), dp(18), dp(20), dp(10));
        head.addView(text("LiteKey", 28, cText, true));
        head.addView(text("Light keyboard \u2022 EN FR AR \u2022 voice dictation", 13, cSub, false));
        root.addView(head);

        // tab bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(4), dp(4), dp(4), dp(4));
        bar.setBackground(round(cCard, 16, cLine));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.setMargins(dp(16), dp(4), dp(16), dp(10));
        root.addView(bar, blp);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = text(TAB_NAMES[i], 14, cSub, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(10), 0, dp(10));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { selectTab(idx); }
            });
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            tabs[i] = t;
        }

        // pages
        scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(2), dp(16), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        for (int i = 0; i < 4; i++) {
            pages[i] = new LinearLayout(this);
            pages[i].setOrientation(LinearLayout.VERTICAL);
        }
        buildSetup(pages[0]);
        buildVoice(pages[1]);
        buildLanguages(pages[2]);
        buildLook(pages[3]);

        setContentView(root);
        selectTab(Math.max(0, Math.min(3, prefs.getInt("settab", 0))));
    }

    private void selectTab(int i) {
        curTab = i;
        prefs.edit().putInt("settab", i).apply();
        for (int k = 0; k < 4; k++) {
            boolean on = k == i;
            tabs[k].setTextColor(on ? 0xFFFFFFFF : cSub);
            tabs[k].setBackground(on ? round(ACCENT, 12, 0) : null);
        }
        content.removeAllViews();
        content.addView(pages[i]);
        scroll.scrollTo(0, 0);
    }

    // ------------------------------------------------------------------ tabs

    private void buildSetup(LinearLayout page) {
        LinearLayout c = card(page, "Status");
        setupStatus = text("", 15, cText, false);
        setupStatus.setLineSpacing(0, 1.2f);
        c.addView(setupStatus);

        c = card(page, "Get started");
        button(c, "1. Enable LiteKey", true, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)); }
        });
        button(c, "2. Choose LiteKey as your keyboard", false, new View.OnClickListener() {
            @Override public void onClick(View v) { imm.showInputMethodPicker(); }
        });

        c = card(page, "Try it");
        EditText test = field("Tap here to type...");
        test.setSingleLine(false);
        test.setMinLines(2);
        c.addView(test);
    }

    private void buildVoice(LinearLayout page) {
        LinearLayout c = card(page, "Status");
        voiceStatus = text("", 14, cText, false);
        voiceStatus.setLineSpacing(0, 1.2f);
        c.addView(voiceStatus);
        button(c, "Allow microphone", false, new View.OnClickListener() {
            @Override public void onClick(View v) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); }
        });

        c = card(page, "Speech engine");
        RadioGroup eg = new RadioGroup(this);
        radio(eg, "Cloud \u2013 Groq whisper-large-v3 (most accurate)", 301);
        radio(eg, "Offline \u2013 Whisper on the phone (private)", 300);
        eg.check("offline".equals(prefs.getString("engine", "cloud")) ? 300 : 301);
        eg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int id) {
                prefs.edit().putString("engine", id == 301 ? "cloud" : "offline").apply();
                updateVoiceStatus(null);
            }
        });
        c.addView(eg);
        body(c, "Cloud mode sends each recording to Groq. Offline mode keeps audio on the phone.");

        c = card(page, "Dictation language");
        final String[] dv = {"follow", "ar", "auto"};
        RadioGroup dg = new RadioGroup(this);
        String[] dn = {"Follow the keyboard language", "Always Arabic (Darija, Arabic letters)", "Auto-detect"};
        String cur = prefs.getString("dictlang", "follow");
        for (int i = 0; i < 3; i++) {
            RadioButton rb = radio(dg, dn[i], 200 + i);
            if (dv[i].equals(cur)) rb.setChecked(true);
        }
        dg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int id) {
                prefs.edit().putString("dictlang", dv[id - 200]).apply();
            }
        });
        c.addView(dg);

        c = card(page, "Darija vocabulary");
        Switch vs = new Switch(this);
        vs.setText("Send vocabulary hint (Arabic dictation, cloud)");
        vs.setTextSize(14);
        vs.setTextColor(cText);
        vs.setChecked(prefs.getBoolean("vocab", true));
        vs.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{ACCENT, cSub}));
        vs.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{0x663D7BFF, cLine}));
        vs.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                prefs.edit().putBoolean("vocab", on).apply();
            }
        });
        c.addView(vs);
        body(c, "A fixed list of everyday Moroccan Darija words and phrases, sent with every Arabic recording "
                + "so Groq spells Darija the way it is written. It cannot be edited.");
        TextView vt = text(Vocab.DARIJA_PROMPT, 14, cText, false);
        vt.setTextDirection(View.TEXT_DIRECTION_RTL);
        vt.setLineSpacing(0, 1.25f);
        vt.setPadding(dp(12), dp(10), dp(12), dp(10));
        vt.setBackground(round(cField, 12, cLine));
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-1, -2);
        vlp.setMargins(0, dp(6), 0, 0);
        c.addView(vt, vlp);

        c = card(page, "Groq API key");
        body(c, "A key is already built into this app. Paste another one only if you want to override it.");
        EditText key = field("gsk_...  (optional override)");
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(prefs.getString("groqkey", ""));
        key.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) {
                prefs.edit().putString("groqkey", e.toString().trim()).apply();
                updateVoiceStatus(null);
            }
        });
        c.addView(key);

        c = card(page, "Offline voice model");
        body(c, "Downloaded once, then works without internet. Start with Tiny on older phones.");
        final String[] files = {"ggml-tiny-q5_1.bin", "ggml-base-q5_1.bin", "ggml-small-q5_1.bin"};
        final RadioGroup mg = new RadioGroup(this);
        String[] mn = {"Tiny  ~31 MB \u2013 fastest",
                       "Base  ~57 MB \u2013 balanced",
                       "Small  ~181 MB \u2013 most accurate, needs a fast phone"};
        for (int i = 0; i < 3; i++) radio(mg, mn[i], 100 + i);
        mg.check(100);
        c.addView(mg);
        button(c, "Download selected model", true, new View.OnClickListener() {
            @Override public void onClick(View v) { download(HF + files[mg.getCheckedRadioButtonId() - 100]); }
        });
        button(c, "Import a ggml model file", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_MODEL);
            }
        });

        c = card(page, "How to use");
        body(c, "Tap the mic key next to ?123 and speak. It stops by itself after a short silence. "
                + "Tap it again to stop sooner, or to cancel while the seconds counter is showing.");
    }

    private void buildLanguages(LinearLayout page) {
        LinearLayout c = card(page, "Keyboard languages");
        final String[] codes = {"en", "fr", "ar"};
        String[] names = {"English", "Fran\u00e7ais (French)", "\u0627\u0644\u0639\u0631\u0628\u064a\u0629 (Arabic)"};
        final CheckBox[] cbs = new CheckBox[3];
        String on = prefs.getString("langs", "en");
        for (int i = 0; i < 3; i++) {
            cbs[i] = new CheckBox(this);
            cbs[i].setText(names[i]);
            cbs[i].setTextSize(15);
            cbs[i].setTextColor(cText);
            cbs[i].setButtonTintList(tint());
            cbs[i].setPadding(dp(6), dp(8), 0, dp(8));
            cbs[i].setChecked(on.contains(codes[i]));
            cbs[i].setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton v, boolean ch) {
                    StringBuilder sb = new StringBuilder();
                    for (int j = 0; j < 3; j++)
                        if (cbs[j].isChecked()) sb.append(sb.length() > 0 ? "," : "").append(codes[j]);
                    if (sb.length() == 0) { cbs[0].setChecked(true); return; }   // keep at least one
                    prefs.edit().putString("langs", sb.toString()).apply();
                }
            });
            c.addView(cbs[i]);
        }
        c = card(page, "Switching fast");
        body(c, "With two or more languages enabled, swipe left or right on the space bar, or long-press it, "
                + "to change language. The space bar shows the current language.");
        c = card(page, "Symbols");
        body(c, "Tap ?123 for numbers and everyday signs, then =\\< for a second page with currency, brackets and more.");
    }

    private void buildLook(LinearLayout page) {
        LinearLayout c = card(page, "Appearance");
        Switch sw = new Switch(this);
        sw.setText("Dark mode");
        sw.setTextSize(15);
        sw.setTextColor(cText);
        sw.setChecked(dark);
        sw.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{ACCENT, cSub}));
        sw.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{0x663D7BFF, cLine}));
        sw.setPadding(0, dp(6), 0, dp(6));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                prefs.edit().putBoolean("dark", on).apply();
                recreate();   // restyle this screen; the keyboard picks it up next time it opens
            }
        });
        c.addView(sw);
        body(c, "Applies to the keyboard and to these settings. You can also flip it from the Light/Dark key on the keyboard.");

        c = card(page, "About");
        body(c, "LiteKey " + versionName() + "\nBuilt with a plain toolchain. English, French and Arabic layouts, "
                + "offline and cloud dictation.");
    }

    private String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return ""; }
    }

    // ------------------------------------------------------------------ status

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) updateStatus();
    }

    private void updateStatus() {
        updateVoiceStatus(null);
        String pkg = getPackageName();
        boolean enabled = false;
        for (InputMethodInfo i : imm.getEnabledInputMethodList())
            if (i.getPackageName().equals(pkg)) enabled = true;
        String def = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean isDefault = def != null && def.startsWith(pkg + "/");
        setupStatus.setText((enabled ? "\u2714  Enabled" : "\u2718  Not enabled yet")
                + "\n" + (isDefault ? "\u2714  Your default keyboard" : "\u2718  Not your default keyboard yet"));
    }

    private void updateVoiceStatus(String extra) {
        boolean mic = VoiceInput.hasMic(this), model = VoiceInput.hasModel(this);
        boolean cloud = "cloud".equals(prefs.getString("engine", "cloud"));
        StringBuilder sb = new StringBuilder();
        sb.append(mic ? "\u2714  Microphone allowed" : "\u2718  Microphone not allowed");
        if (cloud) {
            sb.append("\n\u2714  Cloud: Groq whisper-large-v3 (")
              .append(Secrets.customKey(this) ? "your key" : "built-in key").append(")");
        } else {
            sb.append("\n").append(model ? "\u2714  Offline model installed (" + VoiceInput.modelFile(this).length() / 1000000 + " MB)"
                                          : "\u2718  No offline model yet");
            sb.append("\n").append(Whisper.AVAILABLE ? "\u2714  Offline engine loaded" : "\u2718  Offline engine not supported on this phone");
        }
        if (extra != null) sb.append("\n").append(extra);
        if (voiceStatus != null) voiceStatus.setText(sb.toString());
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        updateVoiceStatus(null);
    }

    // ------------------------------------------------------------------ offline model import / download

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_MODEL || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (busy) return;
        busy = true;
        updateVoiceStatus("Importing...");
        new Thread(new Runnable() {
            @Override public void run() {
                String msg;
                try {
                    InputStream in = getContentResolver().openInputStream(uri);
                    msg = save(in, -1);
                } catch (Exception e) { msg = "Import failed"; }
                finish(msg);
            }
        }).start();
    }

    private String save(InputStream in, long total) throws Exception {
        File part = new File(getFilesDir(), "whisper-model.part");
        OutputStream out = new FileOutputStream(part);
        try {
            byte[] b = new byte[65536];
            long done = 0, last = 0;
            int r;
            while ((r = in.read(b)) > 0) {
                out.write(b, 0, r);
                done += r;
                long now = System.currentTimeMillis();
                if (now - last > 400) {
                    last = now;
                    final String m = "Saving... " + done / 1000000 + (total > 0 ? " / " + total / 1000000 : "") + " MB";
                    runOnUiThread(new Runnable() { @Override public void run() { updateVoiceStatus(m); } });
                }
            }
        } finally { out.close(); in.close(); }
        if (part.length() < 5L * 1024 * 1024) { part.delete(); return "That file is too small to be a model"; }
        File dst = VoiceInput.modelFile(this);
        dst.delete();
        return part.renameTo(dst) ? "Model installed" : "Could not save the model";
    }

    private void download(final String url) {
        if (busy) return;
        busy = true;
        updateVoiceStatus("Connecting...");
        new Thread(new Runnable() {
            @Override public void run() {
                String msg;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    if (c.getResponseCode() != 200) msg = "Download failed (HTTP " + c.getResponseCode() + ")";
                    else msg = save(c.getInputStream(), c.getContentLength());
                } catch (Exception e) { msg = "Download failed: check your internet"; }
                finish(msg);
            }
        }).start();
    }

    private void finish(final String msg) {
        busy = false;
        runOnUiThread(new Runnable() { @Override public void run() { updateVoiceStatus(msg); } });
    }
}
