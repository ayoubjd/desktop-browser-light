package com.lite.keyboard;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Offline dictation: record 16 kHz mono, stop automatically after ~1.5 s of silence
 * (or when the mic key is tapped again), then run whisper.cpp on the audio.
 */
final class VoiceInput {
    static final int IDLE = 0, LISTENING = 1, PROCESSING = 2;

    interface Listener {
        void onState(int state);
        void onText(String text);
        void onMessage(String msg);
        void onTick(int seconds);
    }

    private static final int RATE = 16000, CHUNK = 1600, MAX_SEC = 30, TIMEOUT_SEC = 90;

    private final Context ctx;
    private final Listener cb;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private volatile boolean stopReq, cancelReq;
    private volatile int state = IDLE;
    private long handle;   // only touched on the executor thread

    VoiceInput(Context c, Listener l) { ctx = c.getApplicationContext(); cb = l; }

    static File modelFile(Context c) { return new File(c.getFilesDir(), "whisper-model.bin"); }

    static boolean hasModel(Context c) { return modelFile(c).length() > 5L * 1024 * 1024; }

    static boolean hasMic(Context c) {
        return c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    int state() { return state; }

    /** Mic key: stop recording early, or cancel the transcription if it is already running. */
    void stop() {
        if (state == PROCESSING) { cancelReq = true; Whisper.nativeCancel(); }
        stopReq = true;
    }
    void cancel() { cancelReq = true; stopReq = true; }

    void start(final String lang) {
        if (state != IDLE) return;
        stopReq = false; cancelReq = false;
        main.removeCallbacks(freeTask);
        setState(LISTENING);
        exec.execute(new Runnable() { @Override public void run() { runOnce(lang); } });
    }

    private void setState(final int s) {
        state = s;
        main.post(new Runnable() { @Override public void run() { cb.onState(s); } });
    }

    private void msg(final String m) {
        main.post(new Runnable() { @Override public void run() { cb.onMessage(m); } });
    }

    private void runOnce(String lang) {
        float[] pcm = new float[RATE * MAX_SEC];
        int n = 0;
        boolean speech = false;
        AudioRecord ar = null;
        try {
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            ar = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, RATE * 2));
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) { msg("Microphone unavailable"); setState(IDLE); return; }
            ar.startRecording();
            short[] buf = new short[CHUNK];
            double noise = Double.MAX_VALUE;
            int chunk = 0, silent = 0, waiting = 0;
            while (!stopReq && n + CHUNK <= pcm.length) {
                int r = ar.read(buf, 0, CHUNK);
                if (r <= 0) break;
                double sum = 0;
                for (int i = 0; i < r; i++) { pcm[n + i] = buf[i] / 32768f; sum += (double) buf[i] * buf[i]; }
                n += r;
                double rms = Math.sqrt(sum / r);
                chunk++;
                if (chunk <= 3) { noise = Math.min(noise, rms); continue; }   // ~300 ms noise calibration
                double thr = Math.max(noise * 2.5, 450);
                if (rms > thr) { speech = true; silent = 0; }
                else if (speech) { if (++silent >= 15) break; }               // 1.5 s of silence -> done
                else if (++waiting >= 70) break;                              // 7 s and nobody spoke
            }
        } catch (Throwable t) {
            msg("Recording failed");
            n = 0;
        } finally {
            if (ar != null) { try { ar.stop(); } catch (Throwable ignored) { } ar.release(); }
        }

        if (cancelReq || n < RATE / 2 || !speech) {
            if (!cancelReq) msg("No speech heard");
            setState(IDLE);
            return;
        }

        setState(PROCESSING);
        final long t0 = System.currentTimeMillis();
        startTicker(t0);
        if ("cloud".equals(ctx.getSharedPreferences("kb", Context.MODE_PRIVATE).getString("engine", "cloud"))) {
            String text = null;
            try { text = cloud(pcm, n, lang); } catch (Throwable t) { msg("Cloud error"); }
            if (!cancelReq && text != null) {
                text = clean(text.getBytes());
                if (text.length() > 0) postText(text); else msg("Nothing recognised");
            }
            stopTicker();
            setState(IDLE);
            return;
        }
        try {
            if (handle == 0) {
                msg("Loading voice model...");
                handle = Whisper.nativeInit(modelFile(ctx).getAbsolutePath());
            }
            if (handle == 0) { msg("Could not load the voice model (file damaged or not a whisper ggml model)"); stopTicker(); setState(IDLE); return; }
            int threads = Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() / 2));
            byte[] out = Whisper.nativeTranscribe(handle, Arrays.copyOf(pcm, n), n, lang, threads, TIMEOUT_SEC);
            long secs = (System.currentTimeMillis() - t0) / 1000;
            String text = clean(out);
            if (cancelReq) { /* user cancelled */ }
            else if (text.length() > 0) {
                postText(text);
                if (secs >= 12) msg("Took " + secs + " s - a smaller model would be faster");
            }
            else if (out == null && secs >= TIMEOUT_SEC - 1) msg("Too slow on this phone (" + TIMEOUT_SEC + " s). Use the Tiny model.");
            else msg("Nothing recognised");
        } catch (Throwable t) {
            msg("Voice engine error");
        }
        stopTicker();
        setState(IDLE);
        main.postDelayed(freeTask, 120000);   // release model memory after 2 idle minutes
    }

    // ---- Cloud mode: Groq (OpenAI-compatible) speech-to-text, model whisper-large-v3 ----
    private static final String GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions";

    private static byte[] wav(float[] pcm, int n) {
        byte[] b = new byte[44 + n * 2];
        int dataLen = n * 2, rate = 16000;
        String hdr = "RIFF";
        for (int i = 0; i < 4; i++) b[i] = (byte) hdr.charAt(i);
        le32(b, 4, 36 + dataLen);
        String f = "WAVEfmt ";
        for (int i = 0; i < 8; i++) b[8 + i] = (byte) f.charAt(i);
        le32(b, 16, 16); b[20] = 1; b[22] = 1;          // PCM, mono
        le32(b, 24, rate); le32(b, 28, rate * 2);
        b[32] = 2; b[34] = 16;                          // block align, bits
        String d = "data";
        for (int i = 0; i < 4; i++) b[36 + i] = (byte) d.charAt(i);
        le32(b, 40, dataLen);
        for (int i = 0; i < n; i++) {
            int v = Math.max(-32768, Math.min(32767, Math.round(pcm[i] * 32768f)));
            b[44 + 2 * i] = (byte) (v & 0xff);
            b[45 + 2 * i] = (byte) ((v >> 8) & 0xff);
        }
        return b;
    }

    private static void le32(byte[] b, int o, int v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    private static void field(OutputStream o, String boundary, String name, String value) throws Exception {
        o.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n"
                + value + "\r\n").getBytes("UTF-8"));
    }

    /** Returns the transcript, or null after posting an explanatory message. */
    private String cloud(float[] pcm, int n, String lang) throws Exception {
        String key = Secrets.groqKey(ctx);
        if (key.length() == 0) { msg("Add your Groq API key in the LiteKey app"); return null; }
        String boundary = "----LiteKey" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL(GROQ_URL).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setDoOutput(true);
            c.setRequestMethod("POST");
            c.setRequestProperty("Authorization", "Bearer " + key);
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            OutputStream o = c.getOutputStream();
            field(o, boundary, "model", "whisper-large-v3");
            if (!"auto".equals(lang)) field(o, boundary, "language", lang);   // "ar" -> Arabic script
            boolean hint = "ar".equals(lang)
                    && ctx.getSharedPreferences("kb", Context.MODE_PRIVATE).getBoolean("vocab", true);
            if (hint) field(o, boundary, "prompt", Vocab.DARIJA_PROMPT);   // same fixed Darija vocabulary every time
            field(o, boundary, "response_format", "json");
            field(o, boundary, "temperature", "0");
            o.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n"
                    + "Content-Type: audio/wav\r\n\r\n").getBytes("UTF-8"));
            o.write(wav(pcm, n));
            o.write(("\r\n--" + boundary + "--\r\n").getBytes("UTF-8"));
            o.flush();
            o.close();
            int code = c.getResponseCode();
            if (code != 200) {
                if (code == 401) msg("Groq rejected the API key (401)");
                else if (code == 429) msg("Groq rate limit reached - try again in a moment");
                else msg("Groq error " + code);
                return null;
            }
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            in.close();
            String out = new JSONObject(bo.toString("UTF-8")).optString("text", "").trim();
            // Whisper sometimes echoes the prompt back when the clip is silent or very short: drop that
            if (hint && out.length() > 8 && Vocab.DARIJA_PROMPT.contains(out)) return "";
            return out;
        } catch (java.io.IOException e) {
            msg("No connection to Groq - check your internet");
            return null;
        } finally {
            c.disconnect();
        }
    }

    private volatile boolean ticking;

    private void startTicker(final long t0) {
        ticking = true;
        main.post(new Runnable() {
            @Override public void run() {
                if (!ticking) return;
                cb.onTick((int) ((System.currentTimeMillis() - t0) / 1000));
                main.postDelayed(this, 500);
            }
        });
    }

    private void stopTicker() { ticking = false; }

    private void postText(final String t) {
        main.post(new Runnable() { @Override public void run() { cb.onText(t); } });
    }

    private static String clean(byte[] b) {
        if (b == null) return "";
        String s;
        try { s = new String(b, "UTF-8"); } catch (Exception e) { return ""; }
        s = s.trim();
        // whisper emits tags like [BLANK_AUDIO] or (music) for non-speech
        if (s.matches("^[\\[(].*[\\])]$")) return "";
        return s;
    }

    private final Runnable freeTask = new Runnable() {
        @Override public void run() {
            exec.execute(new Runnable() {
                @Override public void run() {
                    if (state == IDLE && handle != 0) { Whisper.nativeFree(handle); handle = 0; }
                }
            });
        }
    };

    void destroy() {
        cancel();
        main.removeCallbacks(freeTask);
        exec.execute(new Runnable() {
            @Override public void run() { if (handle != 0) { Whisper.nativeFree(handle); handle = 0; } }
        });
        exec.shutdown();
    }
}
