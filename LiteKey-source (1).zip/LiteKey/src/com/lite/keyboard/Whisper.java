package com.lite.keyboard;

/** JNI bridge to whisper.cpp. AVAILABLE is false on devices without the arm64 library. */
final class Whisper {
    static boolean AVAILABLE;
    static {
        try { System.loadLibrary("litewhisper"); AVAILABLE = true; }
        catch (Throwable t) { AVAILABLE = false; }
    }
    static native long nativeInit(String modelPath);
    static native byte[] nativeTranscribe(long handle, float[] pcm, int n, String lang, int threads, int timeoutSec);
    static native void nativeCancel();
    static native void nativeFree(long handle);
}
